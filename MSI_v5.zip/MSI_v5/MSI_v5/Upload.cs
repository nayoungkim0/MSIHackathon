﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MSI_v5
{
    internal class Upload
    {
        public string pcNumber { get; set; }    
        public DateTime startTime { get; set; }
        public bool isLoginSuccessful { get; set; }

    }
}
